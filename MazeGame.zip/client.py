import generate_maze

import pygame
import os

import socket

 
import time

import json
import threading


pygame.init()

displaywidth = 1280
displayheight = 720

display = pygame.display.set_mode((displaywidth, displayheight))

maze = None

sock = socket.socket()


clients = []

sock.connect(("183.96.193.45", 22122))

images = {}

PLAYER_SIZE = 70

CELL_SIZE = 100

transform_images = {
    "playbutton.png" : (200, 80),
    "smartphone_menu.png" : (80, 80),
    "smartphone.png" : (320, 480),
    "person_back.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_back2.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_right.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_right2.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_left.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_left2.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_front.png": (PLAYER_SIZE, PLAYER_SIZE),
    "person_front2.png": (PLAYER_SIZE, PLAYER_SIZE),
    "wall.png" : (CELL_SIZE, CELL_SIZE)

}

buffer = []



PLAYER_X = displaywidth / 2 - PLAYER_SIZE / 2
PLAYER_Y = displayheight / 2 - PLAYER_SIZE / 2



FPS = 80

clock = pygame.time.Clock()


class GameObject:
    def __init__(self, x, y, image : pygame.Surface, collidable=False, drawable=True):
        self.x = x
        self.y = y
        self.image = image
        self.collidable = collidable
        self.drawable = drawable
        self.rect = pygame.Rect(x, y, image.get_width(), image.get_height())
    def update(self):
        self.rect = pygame.Rect(self.x, self.y, self.image.get_width(), self.image.get_height())




class Player:

    def __init__(self) -> None:
        
        self.x = 100
        self.y = 1000
        self.istwo = False  
        self.pressed_key = "None"
        self.direction = "front"
        self.place = "Deajon"
        
        self.maxspeed = 10
        self.speed = self.maxspeed
        self.objects = []
        
        self.drawable = True
        self.rect = pygame.Rect(self.x + PLAYER_X,
                                self.y + PLAYER_Y,
                                PLAYER_SIZE, 
                                 PLAYER_SIZE
                                )
        

    def draw(self):
        if self.drawable:
            
            image = f"person_{self.direction}.png"
            display.blit(images[image], (PLAYER_X, PLAYER_Y))

    def update_object(self):
        for targetobject in self.objects:
            
                    
                   
             
            # draw objects
            if targetobject.drawable == True:
                display.blit(targetobject.image, (targetobject.x - self.x, targetobject.y - self.y))
            # update objects
            targetobject.update()

    def add_object(self, gameobject : GameObject):
        self.objects.append(gameobject)

    def move(self):
        
        if self.pressed_key == "d":
            
            newrect = self.rect
            newrect.x += self.speed
            if all((targetobject.collidable == True and not targetobject.rect.colliderect(newrect)) or targetobject.collidable == False for targetobject in self.objects):
                
                self.x += self.speed
        if self.pressed_key == "w":
            newrect = self.rect
            newrect.y -= self.speed
            if all((targetobject.collidable == True and not targetobject.rect.colliderect(newrect)) or targetobject.collidable == False for targetobject in self.objects):
                
        
                self.y -= self.speed
        if self.pressed_key == "s":
            newrect = self.rect
            newrect.y += self.speed
            if all((targetobject.collidable == True and not targetobject.rect.colliderect(newrect)) or targetobject.collidable == False for targetobject in self.objects):
                self.y += self.speed
        if self.pressed_key == "a":
            newrect = self.rect
            newrect.x -= self.speed
            if all((targetobject.collidable == True and not targetobject.rect.colliderect(newrect)) or targetobject.collidable == False for targetobject in self.objects):
                self.x -= self.speed
        
        # print(self.x, ",", self.y)    
    def setDirection(self, event):
        
        if event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_d , pygame.K_RIGHT]:
                self.pressed_key = "d"
                self.direction = "right"
            if event.key in [pygame.K_w, pygame.K_UP]:
                self.pressed_key = "w"
                self.direction = "back"    
            if event.key in [pygame.K_s, pygame.K_DOWN]:
                self.pressed_key = "s"
                self.direction = "front"    
            if event.key in [pygame.K_a, pygame.K_LEFT]:
                self.pressed_key = "a"
                self.direction = "left"    
        # print(self.pressed_key)        
        if event.type == pygame.KEYUP:
            # print("Keyup")
            self.pressed_key = "none"
    def update(self):
        
        self.rect = pygame.Rect(self.x + PLAYER_X,
                                self.y + PLAYER_Y,
                                PLAYER_SIZE,
                                 PLAYER_SIZE
                                )
        
        self.move()
        self.update_object()
    def getState(self):
        return {
            "command" : "player_state",
            "x" : self.x,
            "y" : self.y,
            "direction" : self.direction
        }

class OtherPlayer(GameObject):
    players = {}
    def __init__(self, myid):
        self.id = myid
        print(self.id)
        OtherPlayer.players[self.id] = self
        self.direction = "right"
        
        super().__init__(100, 1000, images["person_right2.png"], False)
    def update(self):
        super().update()
        self.image = images[f"person_{self.direction}.png"]

class Maze_End(GameObject):
    def __init__(self, x, y, player : Player):
        self.player = player
        
        super().__init__(x, y, None, False, False)
    
    def update(self):
        if self.player.rect.colliderect(self.rect):
            print("Clear!")
        

    
    




def init_images():

    global images
    imageFilename = os.listdir("./resources/images")
    for filename in imageFilename:
        
        images[filename] = pygame.transform.scale( pygame.image.load(os.path.join("./resources/images/",  filename)), transform_images.get(filename)) if transform_images.get(filename) else pygame.image.load(os.path.join("./resources/images/",  filename))




tickfreq = clock.tick(FPS)

time_buffer = []

def addToBuffer():
    
    while True:
    
        recvdatas = sock.recv(2048).decode()
        for recvdata in recvdatas.split("~"):
            if recvdata != "":
                
                try:
                    buffer.append(json.loads(recvdata))
                    # time_buffer.append(time.time())
                except Exception:
                    pass
        
        
        

def use_buffer(player):
    global maze
    if len(buffer):
        jsondata = buffer.pop(0)
        # buffertime = time_buffer.pop(0)

        # print(time.time() - buffertime, "buffer-time")
        
        if jsondata and jsondata != "":
            command = jsondata["command"]
            if command == "player":
                
                player.add_object(OtherPlayer(jsondata["id"]))
            
            if command == "maze":
                print("maze")
                maze = generate_maze.tolist(jsondata["maze"])

            if command == "player_state":
                
               
                targetplayer = OtherPlayer.players.get(jsondata["id"])
                if targetplayer:
                    # pass 
                    targetplayer.x = jsondata["x"] + PLAYER_X
                    targetplayer.y = jsondata["y"] + PLAYER_Y
                    targetplayer.direction = jsondata["direction"]
                
def rungame():

    

    player = Player()

    threading.Thread(target=addToBuffer).start()
    while not maze:
        use_buffer(player)
        for event in pygame.event.get(pygame.QUIT):
            pygame.quit()
        display.fill((0, 125, 255))
        pygame.display.update()
        

    for y, row in enumerate(maze):
        for x, cell in enumerate(row):
            cell_x = x * CELL_SIZE
            cell_y = y * CELL_SIZE
            if cell == generate_maze.MAZE_END:
                player.add_object(Maze_End(cell_x, cell_y, player))
            if cell == generate_maze.MAZE_WALL:
                player.add_object(GameObject(cell_x, cell_y, images["wall.png"], True))

    

    while True:

        use_buffer(player)
        
        
        display.fill((0, 0, 0))

        

        player.update()

        

        player.draw()

        for event in pygame.event.get():

            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                showminimap(maze)

            player.setDirection(event)
            if event.type == pygame.QUIT:
                pygame.quit()
        pygame.display.update()

        jsondata = player.getState()

        send_json(jsondata)

        
        clock.tick(FPS)

def send_json(data : dict):
    data = json.dumps(data) + "~"
    sock.send(data.encode())

def showminimap(maze):
    for row in maze:
        for cell in row:
            print(" " if cell == generate_maze.MAZE_EMPTY else "■", end="")
        print()

init_images()
rungame()