import socket
import json
import threading

import generate_maze

import traceback

import time

sock = socket.socket()


clients = []

player_data = []

maze = generate_maze.generate_maze(43, 43)



sock.bind(("127.0.0.1", 22122))

def client_thread(conn, addr):
    
    client_notmine = clients

    buffer = []
    
    

    myid = len(clients)

    

    
    

    
    try:
        #
        send_json(conn, {"command" : "maze", "maze" : generate_maze.tostring(maze)})  
        print("abd")
        for data in player_data:
            data["command"] = "player"
            send_json(conn, data)
        
        player_data.append({"id" : myid})
        send_json_not_me(conn, {"command" : "player", "id" : myid})
        while True:
            
            recvdata = conn.recv(2048).decode()
            
            buffer.append(recvdata.split("~")[0])
            
            strdata = buffer[0]
            
            del buffer[0]
        

            # print(f"len_buffer - id : {myid}, value = {len(buffer)}")
            
            if strdata and strdata != "":
                # print(f"len_split - id : {myid}, value = {len(recvdata.split('~'))}")
                jsondata = json.loads(strdata)
                command = jsondata["command"]
                
                if command == "player_state":
                    # print(recvdata)
                    jsondata["id"] = myid
                    send_json_not_me(conn, jsondata)
            # time.sleep(0.01)
    except Exception as e:
        print(traceback.format_exc())
    finally:
        print("client disconnected or error")
        conn.close()
        clients.remove(conn)
        
        

def send_json_not_me(conn, data : dict):
    send_not_me(conn, json.dumps(data))

def send_not_me(conn, data : str):
    for client in clients:
        if client != conn:
            senddata = data + "~"
            client.send(senddata.encode())

def send_json(conn, data : dict):
    senddata = json.dumps(data) + "~"
    conn.send(senddata.encode())

def run_server():
    while True:
        sock.listen(10)
        conn, addr = sock.accept()

        print("new client connected")

        clients.append(conn)
            
        thread = threading.Thread(target=client_thread, args=(conn, addr,))
        thread.setDaemon(True)
        thread.start()

        

run_server()