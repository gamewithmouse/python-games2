import os

os.system("D:/gamewithmouse")
os.system("cd /gamewithmouse")
os.system("dir")